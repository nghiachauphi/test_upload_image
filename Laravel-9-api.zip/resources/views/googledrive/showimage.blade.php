@extends('layouts.app')

@section('content')
    <div class="d-flex justify-content-center align-items-center" style="max-height: 85%;height: 85%;">
        <img class="img-fluid border border-dark rounded shadow-lg" id="show_image" style="max-height: 100%">

        <div class="row p-0 m-0">
            <h1 role="alert" id="label_update"></h1>
        </div>
    </div>
@endsection
<script>
    window.onload = function()
    {
        HisSpinner(false);
    };
</script>
