@extends('layouts.app')

@section('content')
    <div class="row">
        <div class="col-sm-5">
            Dể suy nghỉ viết gì chổ này
        </div>
        <div class="col-sm-5 scroll-width-one">
            <div class="h-100">
                <table class="table align-middle table-hover table-position-sticky ">
                    <thead class="hdm-table-header bg-primary">
                    <tr>
                        <th class="w-30">Tên file</th>
                        <th class="w-35">Download</th>
                    </tr>
                    </thead>

                    <tbody class="" id="col_one">
                    </tbody>
                </table>
            </div>
        </div>

        <div class="row p-0 m-0">
            <h1 role="alert" id="label_update"></h1>
        </div>
    </div>
@endsection
<script>

    function CreateRowItem(data,name_file)
    {
        var tbody = document.getElementById("col_one");

        var itemTr = document.createElement("tr");

        var name = document.createElement("td");
        name.setAttribute("class", "text-start");
        name.innerText = name_file;

        var td_img = document.createElement("td");
        var img = document.createElement("a");
        img.innerHTML = 'Tải xuống';
        img.setAttribute("href", "https://drive.google.com/file/d/"+ data+ "/view" );
        td_img.append(img);

        itemTr.append(name);
        itemTr.append(td_img);

        tbody.append(itemTr);
        return;
    }

    function GetFileGGDrive()
    {
        HisSpinner();

        axios.get('/api{{$data}}')
            .then(function (response) {
                // handle success
                // console.log(response.data.message[0]);

                var payload = response.data.message[0];
                var link = response.data.message[0].id_ggdrive;
                var name = response.data.message[0].name_file;
                var length_pay = response.data.message[0].id_ggdrive.length;


                for (let i = 0; i < length_pay; i++) {
                    console.log(name[i]);
                    CreateRowItem(link[i],name[i]);
                }

                HisSpinner(false);
            })
            .catch(function (error) {
                // handle error
                // console.log(error);
                HisSpinner(false);
                // show_result("label_update", "File Đã Bị Xóa - The photo has been deleted", "col-12 h-100 alert alert-danger text-center text-uppercase");
            })
            .then(function () {
                // always executed
                HisSpinner(false);
            });
    }

    window.onload = function()
    {
        GetFileGGDrive();
    };
</script>
