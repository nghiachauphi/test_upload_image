<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:image:width" content="300" />
    <meta property="og:image:height" content="300" />
    <meta property="og:image" content="http://leopardjsc.com/img/Leopard-logo_18_012021.png"/>
    <link rel="shortcut icon" href="<?php echo e(asset('image/title_logo.png')); ?>" type="image/x-icon">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">

    <!--   semantic ui    -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/semantic.min.css')); ?>">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('js/semantic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('js/variable.js')); ?>"></script>
</head>
<body>
<!--    alpinejs    -->
<script src="<?php echo e(asset('js/alpine.js')); ?>"></script>
    <div class="his-container-spinner" id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">

                <a class="navbar-brand border border-warning rounded" href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('image/title_logo.png')); ?>" class="m-1">
                    <span class="me-1"><?php echo e(config('app.name', 'Laravel')); ?></span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">
                        <a class="btn btn-primary me-3" id="new_free_image"></a>
                        <a class="btn btn-primary me-3" id="new_free_video"></a>
                        <a class="btn btn-primary me-3" id="new_free_file"></a>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php
                                      $value = Auth::user();
                                    ?>

                                    <?php if( $value->avatar_upload == null || $value->avatar_upload  == ""): ?>
                                        <img class="rounded-circle" src="<?php echo e(Auth::user()->avatar); ?>" style="max-width: 40px; max-height: 40px"/>
                                    <?php else: ?>
                                        <img class="rounded-circle" src="<?php echo e(Auth::user()->avatar_upload); ?>"  style="max-width: 40px; max-height: 40px"/>
                                    <?php endif; ?>

                                    <?php echo e(Auth::user()->name); ?>


                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('user')); ?>">
                                        Thông tin
                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Đăng xuất')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-3 scroll-none-width">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <div class="his-spinner all-center" id="spinner_container_page">
        <div class="his-content-spinner all-center">
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            <span class="m-2" id="spinner_container_page_lable">Loading...</span>
        </div>
    </div>
</body>
<footer id="footer" class="d-flex justify-content-center align-items-center text-center">
        Copyright All Rights Reserved @2022  By Leopard Solutions
</footer>
</html>

<script>
    function GetDataImage(){
        axios.get('/api/user/image')
            .then(function (response) {
                // handle success
                var payload = CheckArrayOrObjectBindData(response.data);
                console.log(payload);

                var src = document.getElementById("bind_avatar");
                src.setAttribute("src", payload.avatar_upload);
            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })
            .then(function () {
                // always executed
            });
    }

    MenuNav("new_free_image", "<?php echo e(route('free_image')); ?>", "Tải Ảnh Mới");
    MenuNav("new_free_video", "<?php echo e(route('free_video')); ?>", "Tải Video Mới");
    MenuNav("new_free_file", "<?php echo e(route('free_file')); ?>", "Tải File Mới");
</script>
<?php /**PATH C:\inetpub\wwwroot\Leopard\Laravel-9-api\resources\views/layouts/app.blade.php ENDPATH**/ ?>