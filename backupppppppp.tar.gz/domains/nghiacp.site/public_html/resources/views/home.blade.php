@extends('layouts.app')

@section('content')

    <div class="container" hidden>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">{{ __('Dashboard') }}</div>

                    <div class="card-body">
                        @if (session('status'))
                            <div class="alert alert-success" role="alert">
                                {{ session('status') }}
                            </div>
                        @endif

                        {{ __('You are logged in!') }}
                    </div>
                </div>
            </div>
        </div>

        <div class=" col-12">
            <canvas id="chart_test"></canvas>
        </div>
    </div>

    <div class="row d-flex justify-content-center" style="height: 45%">
        <div class="col-sm-5 scroll-width-one">
            <div class="h-100">
                <table class="table align-middle table-hover table-position-sticky ">
                    <thead class="hdm-table-header bg-primary">
                    <tr>
                        <th class="">Thời gian tạo</th>
                        <th class="w-30">Link</th>
                        <th class="w-35">Hình ảnh</th>
                    </tr>
                    </thead>

                    <tbody class="" id="col_one">
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-sm-5 scroll-width-one">
            <div class="h-100">
                <table class="table align-middle table-hover table-position-sticky ">
                    <thead class="hdm-table-header bg-primary">
                    <tr>
                        <th class="">Thời gian tạo</th>
                        <th class="w-30">Link</th>
                        <th class="w-35">Video</th>
                    </tr>
                    </thead>
                    <tbody id="col_two">
                    </tbody>
                </table>
            </div>

        </div>

        <div class="col-sm-4 " style="display: none">
            <div class="m-3 h-100" >
                <table class="table align-middle table-hover">
                    <tr>
                        <th class="w-25">Thời gian tạo</th>
                        <th class="w-25">Link</th>
                        <th class="w-50">File</th>
                    </tr>
                    <tbody id="col_three">
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
<script>
    var chart_test = null;

    function CreateRowItem_one(data)
    {
        var tbody = document.getElementById("col_one");

        var itemTr = document.createElement("tr");

        var date = document.createElement("td");
        date.setAttribute("class", "text-start");
        date.innerText = FormatDate(data.created_at);

        var td_link = document.createElement("td");
        var link = document.createElement("a");
        link.setAttribute("class", "text-center text-break");

        if (data.hasOwnProperty("link") && data.link != "")
        {
            link.innerText = ShortText(data.link);
            link.setAttribute("href", "https://nghiacp.site/free_image/" + data.link);
        }
        else
        {
            link.innerText = ShortText(data._id);
            link.setAttribute("href", "https://nghiacp.site/free_image/" + data._id);
        }

        td_link.append(link);

        var td_img = document.createElement("td");
        var img = document.createElement("img");
        img.setAttribute("class", "text-center");
        img.setAttribute("width", "32px");
        img.setAttribute("height", "32px");
        img.setAttribute("src", data.image_base64);
        // img.style.minWidth = "16px";
        // img.style.minHeight = "16px";
        td_img.append(img);

        itemTr.append(date);
        itemTr.append(td_link);
        itemTr.append(td_img);

        tbody.append(itemTr);
        return;
    }

    function CreateRowItem_two(data, stt)
    {
        var tbody = document.getElementById("col_two");

        var itemTr = document.createElement("tr");

        var date = document.createElement("td");
        date.setAttribute("class", "text-start");
        date.innerText = FormatDate(data.created_at);

        var td_link = document.createElement("td");
        var link = document.createElement("a");
        link.setAttribute("class", "text-center text-break");

        if (data.hasOwnProperty("id_ggdrive") && data.id_ggdrive != "")
        {
            link.innerText = ShortText(data.id_ggdrive);
            link.setAttribute("href", "https://nghiacp.site/upload_file/" + data.id_ggdrive);
        }

        td_link.append(link);

        var td_img = document.createElement("td");
        var img = document.createElement("img");
        img.setAttribute("class", "text-center");
        img.setAttribute("src", "https://drive.google.com/u/0/video/captions/edit?id=1oCuUP50__0TxB_ULnpmaIBhKvJhUQy_3");
        img.setAttribute("width", "32px");
        img.setAttribute("height", "32px");
        td_img.append(img);

        itemTr.append(date);
        itemTr.append(td_link);
        itemTr.append(td_img);

        tbody.append(itemTr);
        return;
    }

    function CreateRowItem_three(data, stt)
    {
        var tbody = document.getElementById("col_three");

        var itemTr = document.createElement("tr");

        var arrStt = document.createElement("td");
        arrStt.setAttribute("class", "text-center");
        arrStt.innerText = stt + 1;

        itemTr.append(itemDelete);

        tbody.append(itemTr);
        return;
    }

    function APIGetFreeImage()
    {
        HisSpinner();

        axios.get('/api/free_image/')
            .then(function (response) {
                var payload = response.data.data;

                if (payload.length != 0)
                {
                    for (let i = 0; i < payload.length; i++) {
                        CreateRowItem_one(payload[i]);
                    }
                }

                HisSpinner(false);
            })
            .catch(function (error) {

                HisSpinner(false);
            });

        HisSpinner();

        axios.get('/api/upload_file/')
            .then(function (response) {
                var payload = response.data.data;

                if (payload.length != 0)
                {
                    for (let i = 0; i < payload.length; i++) {
                        CreateRowItem_two(payload[i]);
                    }
                }

                HisSpinner(false);
            })
            .catch(function (error) {

                HisSpinner(false);
            });
    }

    window.onload = function ()
    {
        APIGetFreeImage();
        chart_test = new Chart(document.getElementById("chart_test"),config);
    }

    const config = {
        type: 'line',
        data: {
            labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6'],
            datasets: [
                {
                    label: 'Dataset',
                    data: [1,2,3,4,5,6],
                    borderColor: "#453453",
                    backgroundColor: "#122664",
                    pointStyle: 'circle',
                    pointRadius: 10,
                    pointHoverRadius: 15
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: (ctx) => 'Point Style: ' + ctx.chart.data.datasets[0].pointStyle,
                }
            }
        }
    };
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
